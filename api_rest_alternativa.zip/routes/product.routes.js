
const router = require('express').Router();
const { createProduct, getProducts, updateProduct, deleteProduct } = require('../controllers/product.controller');
const { verifyToken, isAdmin } = require('../middlewares/auth.middleware');

router.post('/', verifyToken, isAdmin, createProduct);
router.get('/', verifyToken, getProducts);
router.put('/:id', verifyToken, isAdmin, updateProduct);
router.delete('/:id', verifyToken, isAdmin, deleteProduct);

module.exports = router;
