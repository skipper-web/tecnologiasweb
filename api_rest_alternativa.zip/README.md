
# API REST - Productos con Autenticación JWT

## Requisitos:
- Node.js
- MongoDB

## Instalación:
1. `npm install`
2. Configura el archivo `.env`
3. `npm start`

## Endpoints:
- POST `/api/auth/register`
- POST `/api/auth/login`
- CRUD `/api/products` (protegido)
